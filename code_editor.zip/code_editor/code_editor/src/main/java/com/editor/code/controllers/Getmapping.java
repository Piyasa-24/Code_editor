package com.editor.code.controllers;

public @interface Getmapping {

}
