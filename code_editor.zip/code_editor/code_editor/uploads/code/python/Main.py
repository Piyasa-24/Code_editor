# Python Example
def hello():
    print("Hello Python")

hello()
