// Write your code here
function hello() {
  console.log("Hello Monaco");
}
hello();